import pandas as pd
import numpy as np
from src.ratio_calculator import calculate_financial_ratios

def calculate_metrics(df):
    """
    Wrapper to use the robust ratio calculator.
    """
    return calculate_financial_ratios(df)

def analyze_risk(df):
    """
    Identifies red flags and assigns a risk score.
    Args:
        df: DataFrame with calculated metrics
    Returns:
        risk_report: Dictionary containing red flags, explanation, and score
    """
    red_flags = []
    
    # Check 1: Revenue Growing but OCF Declining (Last 2 periods if available)
    if len(df) >= 2:
        rev_growth = df['Revenue'].iloc[-1] > df['Revenue'].iloc[-2]
        ocf_decline = df['Operating Cash Flow'].iloc[-1] < df['Operating Cash Flow'].iloc[-2]
        if rev_growth and ocf_decline:
            red_flags.append("Revenue is growing, but Operating Cash Flow is declining. This may indicate poor earnings quality or aggressive revenue recognition.")

    # Check 2: Debt Growing Faster than Revenue (CAGR or simple growth if short period)
    if len(df) >= 2:
        debt_growth = (df['Total Debt'].iloc[-1] - df['Total Debt'].iloc[-2]) / df['Total Debt'].iloc[-2]
        rev_growth_rate = (df['Revenue'].iloc[-1] - df['Revenue'].iloc[-2]) / df['Revenue'].iloc[-2]
        
        if debt_growth > rev_growth_rate and debt_growth > 0:
            red_flags.append("Total Debt is growing faster than Revenue. This raises concerns about the sustainability of leverage.")

    # Check 3: Declining Margins (Last 3 years if available)
    if len(df) >= 3:
        margin_trend = df['Net Margin (%)'].iloc[-3:]
        if (margin_trend.iloc[1] < margin_trend.iloc[0]) and (margin_trend.iloc[2] < margin_trend.iloc[1]):
            red_flags.append("Net Profit Margin has declined for 3 consecutive years, suggesting deteriorating profitability or rising costs.")
    elif len(df) == 2:
         if df['Net Margin (%)'].iloc[-1] < df['Net Margin (%)'].iloc[-2]:
              # Not a strong red flag for just 1 year drop, maybe a warning or skip
              pass

    # Check 4: High Debt-to-Equity
    if df['Debt-to-Equity'].iloc[-1] > 2.0: # Threshold can be adjustable
        red_flags.append(f"Debt-to-Equity ratio is high ({df['Debt-to-Equity'].iloc[-1]:.2f}), indicating high leverage.")

    # Risk Score Calculation
    score_val = len(red_flags)
    if score_val == 0:
        risk_level = "Low"
    elif score_val <= 2:
        risk_level = "Moderate"
    else:
        risk_level = "High"

    return {
        "risk_level": risk_level,
        "score": score_val,
        "red_flags": red_flags
    }
