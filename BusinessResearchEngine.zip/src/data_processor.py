import pandas as pd
import io

def load_data(file):
    """
    Loads data from a CSV or Excel file.
    Args:
        file: Uploaded file object (Streamlit UploadedFile)
    Returns:
        pd.DataFrame: Loaded data
    """
    if file.name.endswith('.csv'):
        return pd.read_csv(file)
    elif file.name.endswith('.xlsx') or file.name.endswith('.xls'):
        return pd.read_excel(file)
    else:
        raise ValueError("Unsupported file format. Please upload a CSV or Excel file.")

def clean_data(df):
    """
    Standardizes column names and ensures required columns exist.
    Args:
        df: Raw DataFrame
    Returns:
        pd.DataFrame: Cleaned DataFrame
        list: List of missing columns (if any)
    """
    # Define standard column names and their expected case
    column_mapping = {
        "year": "Year",
        "revenue": "Revenue",
        "gross profit": "Gross Profit",
        "ebitda": "EBITDA",
        "net profit": "Net Profit",
        "total assets": "Total Assets",
        "total debt": "Total Debt",
        "equity": "Equity",
        "current assets": "Current Assets",
        "current liabilities": "Current Liabilities",
        "operating cash flow": "Operating Cash Flow"
    }
    
    expected_columns = list(column_mapping.values())

    # Standardize column names using the mapping
    new_columns = []
    for col in df.columns:
        col_str = str(col).strip()
        col_lower = col_str.lower()
        if col_lower in column_mapping:
            new_columns.append(column_mapping[col_lower])
        else:
            new_columns.append(col_str) # Keep original if not recognized
            
    df.columns = new_columns

    missing_columns = [col for col in expected_columns if col not in df.columns]
    
    if not missing_columns:
        # Sort by Year if present
        if 'Year' in df.columns:
            df = df.sort_values('Year').reset_index(drop=True)
            
    return df, missing_columns
