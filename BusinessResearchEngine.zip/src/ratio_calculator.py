import pandas as pd
import numpy as np

def safe_divide(numerator, denominator):
    """
    Safely divides two series, handling division by zero and NaNs.
    Args:
        numerator: Pandas Series or float
        denominator: Pandas Series or float
    Returns:
        Pandas Series or float with division result, infinity/NaN handled.
    """
    with np.errstate(divide='ignore', invalid='ignore'):
        result = numerator / denominator
        # Replace inf with 0 or NaN depending on preference. 
        # For financial ratios, extreme values can be misleading. keeping Nan for now.
        result = result.replace([np.inf, -np.inf], np.nan)
    return result

def calculate_growth_metrics(df):
    """Calculates growth metrics like Revenue and Net Profit Growth."""
    try:
        if 'Revenue' in df.columns:
            df['Revenue Growth (%)'] = df['Revenue'].pct_change() * 100
        
        if 'Net Profit' in df.columns:
            df['Net Profit Growth (%)'] = df['Net Profit'].pct_change() * 100
            
        if 'EBITDA' in df.columns:
             df['EBITDA Growth (%)'] = df['EBITDA'].pct_change() * 100
             
    except Exception as e:
        print(f"Error calculating growth metrics: {e}")
    return df

def calculate_margins(df):
    """Calculates profitability margins."""
    try:
        if 'Revenue' in df.columns:
            rev = df['Revenue']
            # Avoid division by zero if revenue is 0
            rev_safe = rev.replace(0, np.nan) 
            
            if 'Gross Profit' in df.columns:
                df['Gross Margin (%)'] = (df['Gross Profit'] / rev_safe) * 100
            
            if 'EBITDA' in df.columns:
                df['EBITDA Margin (%)'] = (df['EBITDA'] / rev_safe) * 100
            
            if 'Net Profit' in df.columns:
                df['Net Margin (%)'] = (df['Net Profit'] / rev_safe) * 100
    except Exception as e:
        print(f"Error calculating margins: {e}")
    return df

def calculate_liquidity_ratios(df):
    """Calculates liquidity ratios like Current Ratio."""
    try:
        if 'Current Assets' in df.columns and 'Current Liabilities' in df.columns:
            df['Current Ratio'] = safe_divide(df['Current Assets'], df['Current Liabilities'])
            
        # Quick Ratio (assuming Inventory is not explicitly provided, but if we had it: (CA - Inventory) / CL)
        # For now, we only have the standard columns.
        
        # Cash Ratio could be calculated if we had 'Cash & Equivalents', but we only have 'Operating Cash Flow' which is different.
    except Exception as e:
        print(f"Error calculating liquidity ratios: {e}")
    return df

def calculate_leverage_ratios(df):
    """Calculates leverage ratios like Debt-to-Equity."""
    try:
        if 'Total Debt' in df.columns:
            if 'Equity' in df.columns:
                df['Debt-to-Equity'] = safe_divide(df['Total Debt'], df['Equity'])
            
            if 'Total Assets' in df.columns:
                df['Debt Ratio'] = safe_divide(df['Total Debt'], df['Total Assets'])
    except Exception as e:
        print(f"Error calculating leverage ratios: {e}")
    return df

def calculate_return_metrics(df):
    """Calculates return metrics like ROA and ROE."""
    try:
        if 'Net Profit' in df.columns:
            if 'Total Assets' in df.columns:
                # Using average assets is better, but ending assets is common for simple analysis
                df['ROA (%)'] = safe_divide(df['Net Profit'], df['Total Assets']) * 100
            
            if 'Equity' in df.columns:
                df['ROE (%)'] = safe_divide(df['Net Profit'], df['Equity']) * 100
    except Exception as e:
        print(f"Error calculating return metrics: {e}")
    return df

def calculate_financial_ratios(df):
    """
    Master function to calculate all financial ratios.
    Args:
        df: DataFrame with standardized columns.
    Returns:
        df: DataFrame with all calculated ratios.
    """
    # Ensure dataframe is not empty
    if df.empty:
        return df
        
    df = calculate_growth_metrics(df)
    df = calculate_margins(df)
    df = calculate_liquidity_ratios(df)
    df = calculate_leverage_ratios(df)
    df = calculate_return_metrics(df)
    
    # Cash Flow specific
    if 'Operating Cash Flow' in df.columns and 'Net Profit' in df.columns:
         df['Cash Flow to Net Income'] = safe_divide(df['Operating Cash Flow'], df['Net Profit'])

    # Fill infinite values with NaN for safer display/plotting
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    
    return df
