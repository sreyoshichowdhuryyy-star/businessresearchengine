import streamlit as st
import pandas as pd
from src.data_processor import load_data, clean_data
from src.financial_analyzer import calculate_metrics, analyze_risk
from src.visualizer import plot_revenue_profit, plot_margins, plot_debt_equity, plot_cash_flow_vs_income

st.set_page_config(page_title="Business Research Engine", layout="wide")

st.title("Business Research Engine")
st.markdown("Upload financial data to generate insights, visualize trends, and assess risk.")

# Sidebar for File Upload
st.sidebar.header("Upload Data")
uploaded_file = st.sidebar.file_uploader("Upload CSV or Excel", type=["csv", "xlsx", "xls"])

if uploaded_file is not None:
    try:
        # Load and Process Data
        raw_df = load_data(uploaded_file)
        df, missing_cols = clean_data(raw_df)

        if missing_cols:
            st.error(f"Missing required columns: {', '.join(missing_cols)}")
            st.warning("Please ensure your file has the following columns: Year, Revenue, Gross Profit, EBITDA, Net Profit, Total Assets, Total Debt, Equity, Current Assets, Current Liabilities, Operating Cash Flow")
        else:
            # Calculate Metrics
            df = calculate_metrics(df)
            
            # Run Risk Analysis
            risk_report = analyze_risk(df)

            # Dashboard Layout
            tab1, tab2, tab3 = st.tabs(["Overview", "Financial Analysis", "Risk Report"])

            with tab1:
                st.header("Financial Overview")
                
                # Key Metrics (Most recent year)
                latest = df.iloc[-1]
                prev = df.iloc[-2] if len(df) > 1 else None
                
                col1, col2, col3, col4 = st.columns(4)
                
                col1.metric("Revenue", f"${latest['Revenue']:,.0f}", f"{latest['Revenue Growth (%)']:.1f}%" if prev is not None else None)
                col2.metric("Net Profit", f"${latest['Net Profit']:,.0f}", f"{latest['Net Profit Growth (%)']:.1f}%" if prev is not None else None)
                col3.metric("Gross Margin", f"{latest['Gross Margin (%)']:.1f}%", f"{latest['Gross Margin (%)'] - prev['Gross Margin (%)']:.1f}%" if prev is not None else None)
                col4.metric("Net Margin", f"{latest['Net Margin (%)']:.1f}%", f"{latest['Net Margin (%)'] - prev['Net Margin (%)']:.1f}%" if prev is not None else None)

                st.subheader("Data Preview")
                st.dataframe(df.style.format(precision=2))

            with tab2:
                st.header("Deep Dive Analysis")
                
                # Display New Ratios 
                st.subheader("Key Ratios")
                latest = df.iloc[-1]
                
                c1, c2, c3, c4 = st.columns(4)
                if 'Current Ratio' in df.columns: c1.metric("Current Ratio", f"{latest['Current Ratio']:.2f}")
                if 'Debt-to-Equity' in df.columns: c2.metric("Debt-to-Equity", f"{latest['Debt-to-Equity']:.2f}")
                if 'ROA (%)' in df.columns: c3.metric("ROA", f"{latest['ROA (%)']:.1f}%")
                if 'ROE (%)' in df.columns: c4.metric("ROE", f"{latest['ROE (%)']:.1f}%")

                st.divider()

                col1, col2 = st.columns(2)
                
                with col1:
                    st.plotly_chart(plot_revenue_profit(df), use_container_width=True)
                    if 'Total Debt' in df.columns and 'Equity' in df.columns:
                        st.plotly_chart(plot_debt_equity(df), use_container_width=True)
                    
                with col2:
                    st.plotly_chart(plot_margins(df), use_container_width=True)
                    if 'Operating Cash Flow' in df.columns:
                        st.plotly_chart(plot_cash_flow_vs_income(df), use_container_width=True)

            with tab3:
                st.header("Automated Risk Assessment")
                
                level = risk_report["risk_level"]
                color = "green" if level == "Low" else "orange" if level == "Moderate" else "red"
                
                st.markdown(f"### Overall Risk Level: :{color}[{level}]")
                
                if risk_report["red_flags"]:
                    st.warning("Potential Red Flags Detected:")
                    for flag in risk_report["red_flags"]:
                        st.markdown(f"- {flag}")
                else:
                    st.success("No major red flags detected based on the analysis logic.")

    except Exception as e:
        st.error(f"Error processing file: {e}")
        st.write("Please ensure the file format is correct.")

else:
    st.info("Awaiting file upload. Please verify you have the correct columns in your dataset.")
    with st.expander("See required columns"):
        st.write("""
        - Year
        - Revenue
        - Gross Profit
        - EBITDA
        - Net Profit
        - Total Assets
        - Total Debt
        - Equity
        - Current Assets
        - Current Liabilities
        - Operating Cash Flow
        """)
